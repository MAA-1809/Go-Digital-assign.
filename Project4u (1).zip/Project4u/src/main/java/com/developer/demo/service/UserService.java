package com.developer.demo.service;


import com.developer.demo.model.User;
import com.developer.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    public List<User> getAllUser(){
            return userRepository.findAll();
    }
    public void save (User user) {
        userRepository.save(user);
    }

    public void delete (String id) {
        userRepository.deleteById(id);
    }

    public void update (User user, int id) {
        userRepository.save(user);
    }

}
