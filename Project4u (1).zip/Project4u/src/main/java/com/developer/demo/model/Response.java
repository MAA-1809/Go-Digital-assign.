package com.developer.demo.model;

public class Response {
   private Object isSuccess;
   private Object message;

    public Object getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(Object isSuccess) {
        this.isSuccess = isSuccess;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }
}
