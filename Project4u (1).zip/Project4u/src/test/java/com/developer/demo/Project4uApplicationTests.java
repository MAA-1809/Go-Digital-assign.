package com.developer.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project4uApplicationTests {

	@Test
	void contextLoads() {
	}

}
