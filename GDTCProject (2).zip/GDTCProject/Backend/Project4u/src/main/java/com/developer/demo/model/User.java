package com.developer.demo.model;


import org.springframework.format.annotation.NumberFormat;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    private String userName;
    @NumberFormat
    private String phoneNumber;
    private String email;
//    private String CreatedOn;
//    private String ChangedOn;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "fk_user_personal_aadharid")
    private UserPersonal userPersonal;

    public UserPersonal getUserPersonal() {
        return userPersonal;
    }

    public void setUserPersonal(UserPersonal userPersonal) {
        this.userPersonal = userPersonal;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
