package com.developer.demo.service;


import com.developer.demo.model.User;
import com.developer.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    public List<User> getAllUser(){
            return userRepository.findAll();
    }
    public void save (User user) {
        System.out.println("Hello");
        System.out.println(user.getPhoneNumber());
        System.out.println(user.getUserName());
        System.out.println(user.getEmail());
        System.out.println(user.getUserPersonal().getFirstName());
        System.out.println(user.getUserPersonal().getMiddleName());
        System.out.println(user.getUserPersonal().getLastName());
        System.out.println(user.getUserPersonal().getGender());
        System.out.println("Hi" + user.getUserPersonal().getAadharID());
        System.out.println(user.getUserPersonal().getDob());
        userRepository.save(user);
    }

    public void delete (String id) {
        userRepository.deleteById(id);
    }

    public void update (User user, int id) {
        userRepository.save(user);
    }

}
