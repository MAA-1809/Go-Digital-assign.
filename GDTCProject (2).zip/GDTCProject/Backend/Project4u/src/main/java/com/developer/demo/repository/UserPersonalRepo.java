package com.developer.demo.repository;

import com.developer.demo.model.UserPersonal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserPersonalRepo extends JpaRepository<UserPersonal, String> {
}
