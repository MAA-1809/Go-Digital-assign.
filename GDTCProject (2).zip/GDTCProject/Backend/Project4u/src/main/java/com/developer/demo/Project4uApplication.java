package com.developer.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project4uApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project4uApplication.class, args);
	}

}
