package com.developer.demo.controller;

import com.developer.demo.model.Response;
import com.developer.demo.model.User;
import com.developer.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    @Autowired
    UserService userService;


    @GetMapping("/")
    public List<User> getEmployees(){
        return userService.getAllUser();
    }


    @DeleteMapping("/{id}")
    private Response deleteEmployee(@PathVariable("id") String id) {
        try {
            userService.delete(id);
            Response res = new Response();
            res.setIsSuccess(true);
            res.setMessage("Record Deleted Successfully");
            return res;
        } catch (Exception e) {
            Response res = new Response();
            res.setIsSuccess(false);
            res.setMessage("Error Found");
            System.out.println(e);
            return res;
        }
    }

    @PostMapping("/")
    private Response saveEmployee(@RequestBody User user) {
        try {
            userService.save(user);
            Response res = new Response();
            res.setIsSuccess(true);
            res.setMessage("Record Inserted Successfully");
            return res;
        }
        catch (Exception e){
            Response res = new Response();
            res.setIsSuccess(false);
            res.setMessage("Error Found");
            return res;
        }

    }

    @PutMapping("/")
    private Response update(@RequestBody User user) {
        try {
        userService.save(user);
        Response res = new Response();
        res.setIsSuccess(true);
        res.setMessage("Record Updated Successfully");
        return res;
    }
        catch (Exception e){
        Response res = new Response();
        res.setIsSuccess(false);
        res.setMessage("Error Found");
        return res;
    }

}












//    @Autowired
//    private UserRepository userRepository;
//
//    @PostMapping("/")
//    public ResponseEntity<String> saveUsers(@RequestBody User user) {
//        userRepository.save(user);
//        return ResponseEntity.ok("Data saved");
//    }
//
//    @GetMapping("/")
//    public List<User> getUsers(){
//        return userRepository.findAll();
//    }










}
