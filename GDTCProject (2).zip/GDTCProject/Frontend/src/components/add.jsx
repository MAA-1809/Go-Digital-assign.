import { useNavigate } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import './css/add.css';
import swal from 'sweetalert';
function Add() {

    var URL = "http://localhost:8080";
    const [userName, setUserName] = useState();
    const [email, setEmail] = useState();
    const [phoneNumber, setPhoneNumber] = useState();
    const [aadharID, setAadharID] = useState();
    const [dob, setDob] = useState();
    const [firstName, setFirstName] = useState();
    const [middleName, setMiddleName] = useState();
    const [lastName, setLastName] = useState();
    const [fullName, setFullName] = useState();
    const [gender, setGender] = useState();

    let handleSubmit = async (e) => {
        e.preventDefault();
         fetch(URL + "/",{
           method: 'POST',
           headers: {
             'Content-Type': 'application/json'
           },
           body: JSON.stringify({
            userName:userName,
            phoneNumber:phoneNumber,
            email:email,
            userPersonal:{
            firstName:firstName,
            middleName:middleName,
            fullName:fullName,
            lastName:lastName,
            dob:dob,
            gender:gender,
            aadharID:aadharID
            }
            }),
         })
           .then((res) => {
            //    setUserName("");
            //    setEmail("");
            //    setPhoneNumber("");
            //    setAadharID("");
            //    setDob("");
            //    setFirstName("");
            //    setMiddleName("");
            //    setLastName("");
            //    setFullName("");
            //    setGender("");
             swal("Good job!", "Your details is successfully updated!", "success");
             console.log("UserName" + userName);
              //window.location.reload(false);
           })
           .catch((err) => alert("Details Upload Error"));
       };

    return (
        <>
            <div id="#myModal" className="modl fad">
                <div className="modal-dialog modal-lg contact-modal">
                    <div className="modal-content">
                        <div>
                            <div className="modal-header">
                                <h4 className="modal-title">Fill Details</h4>
                            </div>
                            <div className="modal-body">
                                <div className="row">
                                    <div className="col-md-6">
                                    <div className="form-group">
						<input type="text"  onChange={e => setUserName(e.target.value)} className="form-control"  placeholder="Enter your userName" required="required" />
					</div>
					<div className="form-group">
          <input  type="text"  onChange={event => setEmail(event.target.value)} className="form-control"  placeholder="Enter Your Email" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setPhoneNumber(event.target.value)} className="form-control"  placeholder="Enter Your Phone No" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setFirstName(event.target.value)} className="form-control"  placeholder="Enter Your First Name" required="required" />
						</div>
                        <div className="form-group">
          <input type="text"  onChange={event => setMiddleName(event.target.value)} className="form-control"  placeholder="Enter Your Middle Name" required="required" />
						</div>
                                    </div>

                                    <div className="col-md-6">
                                    <div className="form-group">
						<input type="text" onChange={e => setLastName(e.target.value)} className="form-control"  placeholder="Enter your Last Name" required="required" />
					</div>
					<div className="form-group">
          <input  type="text" onChange={event => setFullName(event.target.value)} className="form-control"  placeholder="Enter Your Full Name" required="required" />
						</div>
            <div className="form-group">
          <input type="text" onChange={event => setDob(event.target.value)} className="form-control"  placeholder="Enter Your DOB" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setGender(event.target.value)} className="form-control"  placeholder="Enter Your Gender" required="required" />
						</div>
                        
                        <div className="form-group">
          <input type="text"  onChange={event => setAadharID(event.target.value)} className="form-control"  placeholder="Enter Your Aadhar Id" required="required" />
						</div>
                                    </div>
                                </div>
                            </div>

                            <div className="modal-footer">
                                <button onClick={handleSubmit} className="btn btn-primary" style={{ backgroundColor: "#04AA6D" }}>Add</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Add;
