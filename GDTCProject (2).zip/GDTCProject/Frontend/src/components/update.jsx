import React, { useState ,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import swal from 'sweetalert';
import './css/update.css';
function Update(props) {
    var URL = "http://localhost:8080";


    const  [email, setEmail] = useState(props.email);
    const [nphoneNumber, nsetPhoneNumber] = useState(props.phoneNumber);
    const [aadharID, setAadharID] = useState(props.aadharID);
    const [dob, setDob] = useState(props.dob);
    const [firstName, setFirstName] = useState(props.firstName);
    const [middleName, setMiddleName] = useState(props.middleName);
    const [lastName, setLastName] = useState(props.lastName);
    const [fullName, setFullName] = useState(props.fulltName);
    const [gender, setGender] = useState(props.gender);
    // email = props.email;
    // phoneNumber =props.phoneNumber;
    // aadharID = props.aadharID;
    // dob = props.dob;
    // sfirstName = props.firstName;
    // middleName = props.middleName;
    // lastName = props.lastNam;
    // fullName =props.fullName;
    // gender = props.gender
        //   //  setEmail(props.email);
        //     setPhoneNumber(props.phoneNumber);
        //   //  setAadharID(props.aadharID);
            // setDob(props.dob);
            // ssetFirstName(props.firstName);
            // setMiddleName(props.middleName);
            // setLastName(props.lastName);
            // setFullName(props.fullName);
            // setGender(props.gender);

    console.log("Hello user");
    console.log("Props " + props.firstName);
    console.log("Name " + firstName);
  //const ids = props.id;
    let handleSubmit = async (e) => {
     e.preventDefault();
     if(email == null){
        setEmail(props.email);
     }
     console.log("Phome" + nphoneNumber);
     if(nphoneNumber == null){
        nsetPhoneNumber(props.phoneNumber);
        console.log("Phome" + nphoneNumber);
     }
     if(aadharID == null){
        setAadharID(props.aadharID);
     }
     if(dob == null){
        setDob(props.dob);
     }
     if(firstName == null){
        setFirstName(props.firstName);
     }
     if(middleName == null){
        setMiddleName(props.middleName);
     }
     if(lastName == null){
        setLastName(props.lastName);
     }
     if(gender == null){
        setGender(props.gender);
     }
      fetch(URL + "/",{
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userName:props.userName,
            email: email,
            phoneNumber :nphoneNumber,
            userPersonal : {
                firstName : firstName,
                middleName:middleName,
                lastName:lastName,
                fullName:fullName,
                dob : dob,
                gender:gender,
                aadharID:aadharID
            }
  
        }),
      })
        .then((res) => {
            // setUserName("");
            // setEmail("");
            // setPhoneNumber("");
            // setAadharID("");
            // setDob("");
            // ssetFirstName("");
            // setMiddleName("");
            // setLastName("");
            // setFullName("");
            // setGender("");
          swal("Good job!", "Your details is successfully updated!", "success");
          // window.location.reload(false);
        })
        .catch((err) => alert("Details Upload Error"));
    };
  return (
    <>
<div id="myModal" className="modal fade">
	<div className="modal-dialog modal-login">
		<div className="modal-content">
			<div className="modal-header">				
				<h4 className="modal-title">Update Details</h4>
				<button type="button" className="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div className="modal-body">
				<form>
					<div className="form-group">
						<input type="text" readOnly defaultValue ={props.userName} className="form-control"  placeholder="Enter your userName" required="required" />
					</div>
					<div className="form-group">
          <input  type="text"  onChange={event => setEmail(event.target.value)} defaultValue = {props.email} className="form-control"  placeholder="Enter Your Email" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => nsetPhoneNumber(event.target.value)} defaultValue= {props.phoneNumber} className="form-control"  placeholder="Enter Your Phone No" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setFirstName(event.target.value)} defaultValue={props.firstName} className="form-control"  placeholder="Enter Your First Name" required="required" />
						</div>
                        <div className="form-group">
          <input type="text"  onChange={event => setMiddleName(event.target.value)} defaultValue = {props.middleName} className="form-control"  placeholder="Enter Your Middle Name" required="required" />
						</div>
                        <div className="form-group">
						<input type="text"  onChange={e => setLastName(e.target.value)} defaultValue ={props.lastName} className="form-control"  placeholder="Enter your Last Name" required="required" />
					</div>
					<div className="form-group">
          <input  type="text"  onChange={event => setFullName(event.target.value)} defaultValue = {props.fullName} className="form-control"  placeholder="Enter Your Full Name" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setDob(event.target.value)} defaultValue= {props.dob} className="form-control"  placeholder="Enter Your DOB" required="required" />
						</div>
            <div className="form-group">
          <input type="text"  onChange={event => setGender(event.target.value)} defaultValue={props.gender} className="form-control"  placeholder="Enter Your Gender" required="required" />
						</div>

                        <div className="form-group">
          <input type="text"  onChange={event => setAadharID(event.target.value)} defaultValue={props.aadharID} className="form-control"  placeholder="Enter Your Aadhar Id" required="required" />
						</div>
					<div className="form-group">
						<button onClick={handleSubmit} className="btn btn-primary btn-block btn-lg" >Update</button>
					</div>
				</form>				
			</div>
		</div>
	</div> 
</div>     
    </>
  );
}

export default Update;