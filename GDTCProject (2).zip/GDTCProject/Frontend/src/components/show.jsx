import React, { useState ,useEffect } from 'react';
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import './css/table.css';
import Update from './update';


function User(props) {    
    var URL = "http://localhost:8080";

    const [data, getData] = useState([])
    const [userName, setUserName] = useState(props.userName);
    const [email, setEmail] = useState(props.email);
    const [phoneNumber, setPhoneNumber] = useState(props.phoneNumber);
    const [aadharID, setAadharID] = useState(props.aadharID);
    const [dob, setDob] = useState(props.dob);
    const [firstName, setFirstName] = useState(props.firstName);
    const [middleName, setMiddleName] = useState(props.middleName);
    const [lastName, setLastName] = useState(props.lastName);
    const [fullName, setFullName] = useState(props.fullName);
    const [gender, setGender] = useState(props.gender);

    useEffect(() => {
        fetchData()
    }, [])
    const fetchData = (e) => {
        fetch(URL + "/" ,{
            method: "GET",
            headers: {
                'Content-Type':'application/json',
          }}).then((res) =>
                res.json())
            .then((response) => {
                console.log(response);
                getData(response);
            })
    }

    const deleteData = (name) => {
        axios.delete(URL + "/" + name,{
            method: "DELETE",
            headers: {
                'Content-Type':'application/json',
          }}).then((res)=>{
            console.log(res.data);
            window.location.reload(false);
        }).catch(err=>{
            console.log(err.message)
        })
       };
     
  return (
    <>
    <center>
    <div className="table-responsive">
        <div className="table-wrapper">			
            <div className="table-title">
                <div className="row">
                    <div className="col-xs-4">										
					</div>
					<div className="col-xs-4">
						<h2 style={{color: "black"}} className="text-center">All Student <b>Details</b></h2>
					</div>
                    <div className="col-xs-4">                       
                    </div>
                </div>
            </div>
            <table className="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>UserName</th>
                        <th>Email <i className="fa fa-sort"></i></th>
                        <th>Phone</th>
                        <th>First Name</th>
                        <th>Middle Name</th>
                        <th>Last Name</th>
                        <th>Full Name</th>
                        <th>Gender</th>
                        <th>DOB</th>
                        <th>Aadhar Id</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    {data.map((item, i) => (
                    <tr key={i}>
                        <td>{i+1}</td>
                        <td>{item.userName}</td>
                        <td>{item.email}</td>
                        <td>{item.phoneNumber}</td>
                        <td>{item.userPersonal.firstName}</td>
                        <td>{item.userPersonal.middleName}</td>
                        <td>{item.userPersonal.lastName}</td>
                        <td>{item.userPersonal.fullName}</td>
                        <td>{item.userPersonal.gender}</td>
                        <td>{item.userPersonal.dob}</td>
                        <td>{item.userPersonal.aadharID}</td>
                        <td>
                        <span  style={{cursor: "pointer", color:"blue"}} className="view" onClick={() => { setUserName(item.userName); setGender(item.userPersonal.gender); setPhoneNumber(item.phoneNumber);  setEmail(item.email); setFirstName(item.userPersonal.firstName); setMiddleName(item.userPersonal.middleName); setLastName(item.userPersonal.lastName); setFullName(item.userPersonal.fullName); setAadharID(item.userPersonal.aadharID); setDob(item.userPersonal.dob)} }  title="edit" href="#myModal"  data-toggle="modal"><i className="material-icons">&#xE254;</i></span>
                         &nbsp; &nbsp; &nbsp;<span  style={{cursor: "pointer", color:"red"}} onClick={() => { deleteData(item.userName);   }} className="delete" title="Delete" data-toggle="tooltip"><i className="material-icons">&#xE872;</i></span>
                        </td>
                    </tr> 
                        ))} 
                    
                </tbody>
                
            </table>
          
        </div>
    </div>        
    </center>
    <Update userName= {userName} phoneNumber= {phoneNumber}  aadharID= {aadharID}  email= {email}  dob={dob} firstName={firstName} middleName={middleName} lastName={lastName} fullName={fullName} gender={gender}/>
  
    </>
  );
}

export default User;
